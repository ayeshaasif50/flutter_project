// ignore_for_file: prefer_const_constructors
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Basic setup test', (WidgetTester tester) async {
    // This test just ensures the project runs successfully.
    expect(1 + 1, equals(2));
  });
}
