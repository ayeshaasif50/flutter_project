package com.techease.crud_op

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
