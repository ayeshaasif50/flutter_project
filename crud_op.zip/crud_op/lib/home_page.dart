import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'login_page.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Get the currently logged in user from Firebase
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      backgroundColor: Colors.blue[50], // Set background color of the page
      appBar: AppBar(
        backgroundColor: Colors.blueAccent, // App bar color
        title: Text("MyNotes Home"), // Title on the app bar
        actions: [
          IconButton(
            icon: Icon(Icons.logout), // Logout icon
            onPressed: () async {
              // Logout the user when pressed
              await FirebaseAuth.instance.signOut();
              // Go to login page after logout
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (_) => LoginPage()));
            },
          )
        ],
      ),
      body: Center(
        child: Card(
          elevation: 10, // Shadow of the card
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), // Rounded corners
          margin: EdgeInsets.symmetric(horizontal: 30), // Horizontal margin
          child: Padding(
            padding: EdgeInsets.all(30), // Space inside the card
            child: Column(
              mainAxisSize: MainAxisSize.min, // Take minimum vertical space
              children: [
                Icon(Icons.note_alt_outlined,
                    size: 80, color: Colors.blueAccent), // Note icon
                SizedBox(height: 20), // Space between widgets
                Text("Welcome!",
                    style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue[900])), // Welcome text
                SizedBox(height: 10),
                Text("${user?.email ?? ""}",
                    style: TextStyle(fontSize: 18, color: Colors.blueGrey)),
                // Show user's email. If null, show empty
                SizedBox(height: 30),
                ElevatedButton.icon(
                  onPressed: () async {
                    // Logout when button is pressed
                    await FirebaseAuth.instance.signOut();
                    // Go to login page after logout
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (_) => LoginPage()));
                  },
                  icon: Icon(Icons.logout), // Logout icon inside button
                  label: Text("Logout"), // Button text
                  style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 50), // Button full width
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12))), // Rounded corners
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
