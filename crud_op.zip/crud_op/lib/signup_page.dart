import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'home_page.dart';

class SignupPage extends StatefulWidget {
  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  // Form key to validate the form
  final _formKey = GlobalKey<FormState>();

  // Controllers to get text from input fields
  final emailController = TextEditingController();
  final passController = TextEditingController();
  final confirmController = TextEditingController();

  // To show loading spinner when signing up
  bool loading = false;

  // Function to sign up user
  Future<void> signupUser() async {
    // Validate form first
    if (!_formKey.currentState!.validate()) return;

    setState(() => loading = true); // Start loading

    try {
      // Create new user in Firebase
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passController.text.trim(),
      );

      // Go to HomePage after successful signup
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => HomePage()));
    } on FirebaseAuthException catch (e) {
      // Show error message if signup fails
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message ?? "Signup failed")));
    } finally {
      setState(() => loading = false); // Stop loading
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50], // Background color
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 30, vertical: 80),
        child: Form(
          key: _formKey, // Assign form key
          child: Column(
            children: [
              Icon(Icons.note_add, size: 100, color: Colors.blueAccent), // App icon
              SizedBox(height: 20),
              Text("Create Account",
                  style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[900])), // Heading text
              SizedBox(height: 40),

              // Email input field
              TextFormField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: "Email",
                  prefixIcon: Icon(Icons.email),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                validator: (v) =>
                v!.contains("@") ? null : "Enter a valid email",
              ),
              SizedBox(height: 20),

              // Password input field
              TextFormField(
                controller: passController,
                obscureText: true, // Hide password
                decoration: InputDecoration(
                  labelText: "Password",
                  prefixIcon: Icon(Icons.lock),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                validator: (v) =>
                v!.length < 6 ? "Password must be 6+ characters" : null,
              ),
              SizedBox(height: 20),

              // Confirm password input field
              TextFormField(
                controller: confirmController,
                obscureText: true, // Hide password
                decoration: InputDecoration(
                  labelText: "Confirm Password",
                  prefixIcon: Icon(Icons.lock_outline),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                validator: (v) =>
                v != passController.text ? "Passwords do not match" : null,
              ),
              SizedBox(height: 30),

              // Show loading or Sign Up button
              loading
                  ? CircularProgressIndicator() // Show spinner when loading
                  : ElevatedButton(
                onPressed: signupUser, // Call signup function
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50), // Full width button
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)), // Rounded corners
                ),
                child: Text("Sign Up", style: TextStyle(fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
