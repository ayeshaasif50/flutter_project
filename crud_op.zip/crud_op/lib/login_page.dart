import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'signup_page.dart';
import 'home_page.dart';

class LoginPage extends StatefulWidget {
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  // Form key to validate the form
  final _formKey = GlobalKey<FormState>();

  // Controllers to get text from text fields
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  // To show loading indicator
  bool loading = false;

  // Function to login user
  Future<void> loginUser() async {
    // Validate form first
    if (!_formKey.currentState!.validate()) return;

    setState(() => loading = true); // Start loading

    try {
      // Sign in with email & password using Firebase
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      // Go to HomePage after successful login
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => HomePage()));
    } on FirebaseAuthException catch (e) {
      // Show error message if login fails
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message ?? "Login failed")));
    } finally {
      setState(() => loading = false); // Stop loading
    }
  }

  // Function to reset password
  Future<void> resetPassword() async {
    // Check if email is valid
    if (emailController.text.trim().isEmpty ||
        !emailController.text.contains("@")) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Please enter a valid email")));
      return;
    }

    try {
      // Send password reset email
      await FirebaseAuth.instance
          .sendPasswordResetEmail(email: emailController.text.trim());
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Password reset email sent! Check inbox")));
    } catch (e) {
      // Show error if email sending fails
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error sending email: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50], // Background color
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 30, vertical: 80),
        child: Form(
          key: _formKey, // Assign form key
          child: Column(
            children: [
              Icon(Icons.note_alt, size: 100, color: Colors.blueAccent), // App icon
              SizedBox(height: 20),
              Text("Welcome Back!",
                  style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[900])), // Welcome text
              SizedBox(height: 40),

              // Email input field
              TextFormField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: "Email",
                  prefixIcon: Icon(Icons.email),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                validator: (v) =>
                v!.contains("@") ? null : "Enter a valid email",
              ),
              SizedBox(height: 20),

              // Password input field
              TextFormField(
                controller: passwordController,
                obscureText: true, // Hide password
                decoration: InputDecoration(
                  labelText: "Password",
                  prefixIcon: Icon(Icons.lock),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                validator: (v) =>
                v!.length < 6 ? "Password must be 6+ characters" : null,
              ),
              SizedBox(height: 25),

              // Show loading or login button
              loading
                  ? CircularProgressIndicator() // Show loading spinner
                  : ElevatedButton(
                onPressed: loginUser, // Call login function
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50), // Full width button
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)), // Rounded corners
                ),
                child: Text("Login", style: TextStyle(fontSize: 18)),
              ),
              SizedBox(height: 10),

              // Forgot password button
              TextButton(
                onPressed: resetPassword, // Call reset password function
                child: Text("Forgot Password?",
                    style: TextStyle(color: Colors.blueAccent)),
              ),
              SizedBox(height: 20),

              // Sign up option
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Don't have an account?",
                      style: TextStyle(color: Colors.blueGrey)),
                  TextButton(
                    onPressed: () {
                      // Navigate to Signup page
                      Navigator.push(context,
                          MaterialPageRoute(builder: (_) => SignupPage()));
                    },
                    child: Text("Sign Up",
                        style: TextStyle(
                            color: Colors.blueAccent,
                            fontWeight: FontWeight.bold)),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
