import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Dummy test to avoid errors', () {
    expect(1, 1);
  });
}
